#include <ros/ros.h>
#include <face_rec/recognition_results.h>
#include <robot_audio/robot_tts.h>
#include <robot_audio/robot_iat.h>
#include <robot_audio/Collect.h>
#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <string>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;

// 定义展馆结构体
struct Exhibit {
    string name;         // 展馆名称
    float x, y, z, w;    // 导航目标位置(x,y坐标和四元数)
    string introduction; // 展馆介绍
};

// 初始化展馆信息 - 坐标应与地图中的实际位置匹配
vector<Exhibit> exhibits = {
    {"深圳馆", 1.026, 1.109, -0.012, 1.000, 
     "深圳，是广东副省级市、经济特区。毗邻香港，经济发达，创新力强，有众多世界500强企业，是粤港澳大湾区中心城市。"},
    {"上海馆", 1.073, 2.120, 0.013, 1.000, 
     "上海，简称 “沪” 或 “申”，是中国直辖市，位于长江入海口，是国际经济、金融、贸易、航运、科技创新中心，有独特海派文化。"},
    {"北京馆", 2.48, 0.13, 0.03, 0.99, 
     "北京，中国首都，千年古都与现代都市交融，尽显独特魅力。这里有宏伟的故宫、绵延的长城等历史古迹，见证着岁月的沧桑变迁。"},
    {"广州馆", 2.48, 1.077, -0.026, 1.000, 
     "广州，别称羊城、花城，广东省会。历史悠久，美食诱人，经济发达，是充满魅力与活力的国家中心城市和粤港澳大湾区核心。"},
    {"吉林馆", 2.48, 2.120, -0.032, 0.999, 
     "吉林省，简称 “吉”，地处东北中部，与俄、朝接壤。是重要商品粮基地与老工业基地，有长白山等美景，人文风情浓郁。"}
};

// 出发区位置
const Exhibit start_point = {"。", 0.0, 0.0, 0.0, 1.0, "。"};

// 文本清理函数 - 去除空格和标点符号
string clean_text(const string& input) {
    string result = input;
    // 移除空格
    result.erase(remove_if(result.begin(), result.end(), ::isspace), result.end());
    // 移除标点
    result.erase(remove_if(result.begin(), result.end(), ::ispunct), result.end());
    return result;
}

// 模糊匹配函数 - 提高语音识别容错率
bool fuzzy_match(const string& input, const string& target) {
    string clean_input = clean_text(input);
    string clean_target = clean_text(target);
    
    // 完全匹配
    if(clean_input == clean_target) return true;
    
    // 包含关系
    if(clean_input.find(clean_target) != string::npos || 
       clean_target.find(clean_input) != string::npos) {
        return true;
    }
    
    // 处理缺少"馆"字的情况
    if(clean_target.substr(clean_target.length() - 1) == "馆") {  // 修正后
        string target_without_suffix = clean_target.substr(0, clean_target.length()-1);
        if(clean_input == target_without_suffix || 
           clean_input.find(target_without_suffix) != string::npos) {
            return true;
        }
    }
    
    // 添加常见识别错误的映射
    map<string, string> common_errors = {
        {"被禁", "北京"},
        {"光州", "广州"},
        {"上进", "上海"},
        {"北京", "北京馆"},
        {"广州", "广州馆"},
        {"深圳", "深圳馆"},
        {"上海", "上海馆"},
        {"吉林", "吉林馆"}
    };
    
    for(auto& error : common_errors) {
        if(clean_input.find(error.first) != string::npos) {
            string corrected_input = clean_input;
            size_t pos = corrected_input.find(error.first);
            corrected_input.replace(pos, error.first.length(), error.second);
            
            if(corrected_input == clean_target || 
               corrected_input.find(clean_target) != string::npos) {
                return true;
            }
        }
    }
    
    return false;
}

// 人脸识别服务客户端
bool face_recognition(ros::NodeHandle &nh, string &recognized_name) {
    ros::ServiceClient face_client = nh.serviceClient<face_rec::recognition_results>("face_recognition_results");
    face_rec::recognition_results srv;
    srv.request.mode = 1;  // 从摄像头获取图像
    
    if (face_client.call(srv)) {
        if (srv.response.success && srv.response.result.num > 0) {
            recognized_name = srv.response.result.face_data[0].name;
            return true;
        }
    }
    return false;
}

// 语音合成函数
void speak(ros::NodeHandle &nh, const string &text) {
    ros::ServiceClient tts_client = nh.serviceClient<robot_audio::robot_tts>("voice_tts");
    robot_audio::robot_tts tts_srv;
    tts_srv.request.text = text;
    
    if (tts_client.call(tts_srv)) {
        string cmd = "play " + tts_srv.response.audiopath;
        system(cmd.c_str());
    } else {
        ROS_ERROR("语音合成服务调用失败");
    }
}

// 语音采集和识别函数
string listen(ros::NodeHandle &nh) {
    ros::ServiceClient collect_client = nh.serviceClient<robot_audio::Collect>("voice_collect");
    ros::ServiceClient iat_client = nh.serviceClient<robot_audio::robot_iat>("voice_iat");
    
    // 采集语音
    robot_audio::Collect collect_srv;
    collect_srv.request.collect_flag = 1;
    
    if (collect_client.call(collect_srv)) {
        // 语音识别
        robot_audio::robot_iat iat_srv;
        iat_srv.request.audiopath = collect_srv.response.voice_filename;
        
        if (iat_client.call(iat_srv)) {
            ROS_INFO("语音识别结果: %s", iat_srv.response.text.c_str());
            return iat_srv.response.text;
        }
    }
    
    ROS_WARN("语音采集或识别失败");
    return "";
}

// 导航到指定位置
bool navigate_to(ros::NodeHandle &nh, const Exhibit& exhibit) {
    // 创建move_base动作客户端
    actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> ac("move_base", true);
    
    // 等待move_base服务器启动
    if(!ac.waitForServer(ros::Duration(10.0))) {
        ROS_ERROR("无法连接到move_base服务器");
        speak(nh, "导航系统未响应，请检查系统状态");
        return false;
    }
    
    ROS_INFO("开始导航前往: %s (%.2f, %.2f)", exhibit.name.c_str(), exhibit.x, exhibit.y);
    speak(nh, "好的，请跟我来");
    
    // 设置导航目标
    move_base_msgs::MoveBaseGoal goal;
    goal.target_pose.header.frame_id = "map";
    goal.target_pose.header.stamp = ros::Time::now();
    goal.target_pose.pose.position.x = exhibit.x;
    goal.target_pose.pose.position.y = exhibit.y;
    goal.target_pose.pose.orientation.z = exhibit.z;
    goal.target_pose.pose.orientation.w = exhibit.w;
    
    // 发送导航目标
    ac.sendGoal(goal);
    
    // 等待导航完成，设置超时时间
    bool succeeded = ac.waitForResult(ros::Duration(180.0)); // 3分钟超时
    
    // 检查导航结果
    if (succeeded) {
        actionlib::SimpleClientGoalState state = ac.getState();
        if (state == actionlib::SimpleClientGoalState::SUCCEEDED) {
            ROS_INFO("。: %s", exhibit.name.c_str());
            speak(nh, "。" + exhibit.name + "。" + exhibit.introduction);
            return true;
        } else {
            ROS_WARN("导航未成功，状态: %s", state.toString().c_str());
            speak(nh, "抱歉，导航到" + exhibit.name + "时出现问题");
            return false;
        }
    } else {
        ROS_WARN("导航超时，未能到达: %s", exhibit.name.c_str());
        speak(nh, "导航超时，未能到达" + exhibit.name);
        ac.cancelGoal(); // 取消导航目标
        return false;
    }
}

int main(int argc, char** argv) {
    ros::init(argc, argv, "exhibition_guide_robot");
    ros::NodeHandle nh;
    
    ROS_INFO("导览机器人已启动，等待人脸检测...");
    
    while (ros::ok()) {
        // 人脸检测
        string person_name;
        if (face_recognition(nh, person_name)) {
            ROS_INFO("检测到人脸: %s", person_name.c_str());
            
            // 打招呼
            string greeting = "你好，欢迎您的到来！有什么需要帮助的吗？";
            speak(nh, greeting);
            
            // 等待用户请求
            string request = listen(nh);
            if (request.empty()) {
                speak(nh, "抱歉，我没有听清您的需求，请再说一次。");
                continue;
            }
            
            // 检查是否包含导航请求
            bool is_nav_request = false;
            string target_exhibit = "";
            
            // 遍历所有展馆，查找匹配的请求
            for (const auto& exhibit : exhibits) {
                if (fuzzy_match(request, exhibit.name)) {
                    is_nav_request = true;
                    target_exhibit = exhibit.name;
                    break;
                }
            }
            
            if (is_nav_request) {
                // 找到对应的展馆
                for (const auto& exhibit : exhibits) {
                    if (exhibit.name == target_exhibit) {
                        // 执行导航
                        bool nav_success = navigate_to(nh, exhibit);
                        
                       if (nav_success) {
                 // 导航成功后返回出发区
          speak(nh, "这里就是" + target_exhibit + "啦，我要继续回去工作啦！");
          navigate_to(nh, start_point);
}
                        
                        break;
                    }
                }
            } else {
                // 处理非导航请求
                string response = "对不起，我只能提供展馆导览服务。您可以说“带我去深圳馆”。";
            
            }
            
            // 导航任务完成后，回到待机状态
    
            ROS_INFO("等待下一位访客...");
        }
        
        ros::spinOnce();
        ros::Duration(1.0).sleep(); // 每秒检查一次
    }
    
    return 0;
}
