# 使用说明



底盘相对移动

## 依赖下载 —— 均为ros包
```
$ git clone https://gitee.com/reinovo/pid_lib.git
```

## relative_move编译方式



```
$ catkin_make
```